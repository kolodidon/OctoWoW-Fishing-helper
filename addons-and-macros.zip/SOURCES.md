# Third-party components

## SimpleAutoDelete
Upstream: https://github.com/fondlez/SimpleAutoDelete
Based on commit 71f2b4b8f978808a6e04fb78e4d8cc3aaea8138a.
Local Vanilla adaptation: see LOCAL-CHANGES.txt. Original MIT license is retained.

## SuperAPI
Upstream: https://github.com/balakethelock/SuperAPI
SuperAPI and its embedded libraries are NOT redistributed in this bundle.
The installer downloads commit 901322dc88890a2ea10610b8228fb43c9c2a3610 directly
from the author's repository, checks SHA-256, and installs it unchanged.
This snapshot already supports 511-character macros.

## SuperWoW
https://github.com/balakethelock/SuperWoW
https://github.com/balakethelock/SuperWoW/blob/master/LICENSE.txt
The DLL and launcher are NOT redistributed. Missing binaries are downloaded
directly from the author's pinned 2.2 release and verified by SHA-256.
The author's terms apply to these dependencies.

## Sound and helper macros
FishBite.wav is a generated three-tone signal (1100/1750/1350 Hz).
The root reference WAV matches the game replacement exactly.
Helper macros and installation scripts contain no account settings.

OctoLogin, AutoLogin, game files and personal SavedVariables are not bundled.
