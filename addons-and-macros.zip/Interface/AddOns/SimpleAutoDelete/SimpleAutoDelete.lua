-- SimpleAutoDelete: null / fondlez; local Vanilla 1.12 adaptation.
-- Only explicitly listed item IDs are eligible; no quality/price rules.
SimpleAutoDelete = SimpleAutoDelete or {}
local frame = CreateFrame("Frame")
frame:Hide()
local ready, pending, manual, scanning = false, false, false, false
local elapsed, lootOpen = 0, false
local retryDelay = 0.5

local function say(text)
  DEFAULT_CHAT_FRAME:AddMessage("|cffa0f6aaSimpleAutoDelete|r: " .. text)
end

local function trim(text)
  return (string.gsub(text or "", "^%s*(.-)%s*$", "%1"))
end

local function itemID(link)
  if not link then return nil end
  local _, _, id = string.find(link, "item:(%d+)")
  return tonumber(id)
end

local function linkName(link)
  if not link then return nil end
  local _, _, name = string.find(link, "|h%[(.-)%]|h")
  return name
end

local function emptyList()
  return not next(SimpleAutoDelete.list)
end

local function initialize()
  if type(SimpleAutoDelete) ~= "table" then SimpleAutoDelete = {} end
  local db = SimpleAutoDelete
  -- Old name-only rules cannot silently become destructive ID rules.
  if db.schemaVersion ~= 2 then
    if type(db.list) == "table" and next(db.list) then
      db.legacyNames = db.list
      say("Старый список сохранён, но не активен. Добавьте правила заново по ссылкам.")
    end
    db.list = {}
    db.enabled = false
    db.schemaVersion = 2
  end
  if type(db.list) ~= "table" then db.list = {} end
  -- Reject malformed saved rules rather than guessing their meaning.
  for id, rule in pairs(db.list) do
    if type(id) ~= "number" or id < 1 or id ~= math.floor(id) or type(rule) ~= "table" then
      db.list[id] = nil
    end
  end
  db.enabled = db.enabled == true
  if type(db.delay) ~= "number" or db.delay ~= db.delay or db.delay < 0.1 or db.delay > 5 then db.delay = 0.4 end
  if type(db.verbose) ~= "boolean" then db.verbose = true end
  ready = true
end

local function blocked()
  if UnitAffectingCombat("player") then return true end
  if lootOpen or (LootFrame and LootFrame:IsVisible()) then return true end
  if CursorHasItem() then return true end
  if CursorHasSpell and CursorHasSpell() then return true end
  if SpellIsTargeting and SpellIsTargeting() then return true end
  return false
end

local function cancel()
  pending, manual, elapsed = false, false, 0
  frame:Hide()
end

local function schedule(isManual)
  if not ready or scanning or emptyList() then return end
  if not isManual and not SimpleAutoDelete.enabled then return end
  manual = manual or isManual or false
  pending, elapsed = true, 0
  frame:Show()
end

local function deleteItems(test)
  local stacks, units, retry = 0, 0, false
  if not test and blocked() then return true end
  for bag = 0, (NUM_BAG_SLOTS or 4) do
    for slot = 1, GetContainerNumSlots(bag) do
      local link = GetContainerItemLink(bag, slot)
      local id = itemID(link)
      if id and SimpleAutoDelete.list[id] then
        local texture, count, locked = GetContainerItemInfo(bag, slot)
        count = count or 1
        if test then
          stacks, units = stacks + 1, units + count
          say("Будет удалена вся стопка: " .. link .. " x" .. count .. "; сумка " .. bag .. ", слот " .. slot)
        elseif blocked() then
          return true
        elseif locked then
          retry = true
        else
          -- Recheck exact identity and lock immediately before picking up.
          local current = GetContainerItemLink(bag, slot)
          local t, n, stillLocked = GetContainerItemInfo(bag, slot)
          if itemID(current) == id and SimpleAutoDelete.list[id] and not stillLocked then
            PickupContainerItem(bag, slot)
            if CursorHasItem() then
              -- On 1.12 pickup transfers the entire stack to the empty cursor.
              DeleteCursorItem()
              if CursorHasItem() then
                say("Удаление не завершилось: предмет остался на курсоре. Проверка отложена.")
                return true
              end
              stacks, units = stacks + 1, units + count
              if SimpleAutoDelete.verbose then say("Удалена стопка: " .. link .. " x" .. count) end
            else
              retry = true
            end
          else
            retry = true
          end
        end
      end
    end
  end
  if test then say("Проверка без удаления: " .. stacks .. " стопок, " .. units .. " предметов.") end
  return retry
end

frame:SetScript("OnEvent", function(self, incomingEvent)
  local ev = incomingEvent or event
  if ev == "VARIABLES_LOADED" then
    initialize()
    say("Загружен. Автоочистка " .. (SimpleAutoDelete.enabled and "включена." or "выключена.") .. " /sad status")
    schedule(false)
  elseif ev == "LOOT_OPENED" then
    lootOpen = true
  elseif ev == "LOOT_CLOSED" then
    lootOpen = false
    schedule(false)
  elseif ev == "BAG_UPDATE" or ev == "PLAYER_REGEN_ENABLED" or ev == "ITEM_LOCK_CHANGED" then
    -- Synchronous events caused by our own deletion do not reenter the scan.
    schedule(false)
  end
end)

frame:SetScript("OnUpdate", function(self, delta)
  if not ready or not pending then frame:Hide(); return end
  if not manual and not SimpleAutoDelete.enabled then cancel(); return end
  elapsed = elapsed + (delta or arg1 or 0)
  if elapsed < SimpleAutoDelete.delay then return end
  if blocked() then elapsed = SimpleAutoDelete.delay - retryDelay; return end
  -- Clear pending before scanning: a delayed own BAG_UPDATE can cause at most
  -- one harmless follow-up scan; an empty/no-match pass emits no new events.
  pending, scanning = false, true
  local retry = deleteItems(false)
  scanning = false
  if retry then
    pending = true
    elapsed = SimpleAutoDelete.delay - retryDelay
  else
    cancel()
  end
end)

for _, ev in ipairs({"VARIABLES_LOADED", "BAG_UPDATE", "LOOT_OPENED", "LOOT_CLOSED", "PLAYER_REGEN_ENABLED", "ITEM_LOCK_CHANGED"}) do
  frame:RegisterEvent(ev)
end

local function resolve(text, removing)
  text = trim(text)
  local id = itemID(text)
  if not id and string.find(text, "^%d+$") then id = tonumber(text) end
  if id and id > 0 and id == math.floor(id) then
    return id, linkName(text) or GetItemInfo(id) or ("item:" .. id)
  end
  if text == "" then return nil end
  local found, name
  local function consider(candidate, candidateName)
    if candidateName and string.lower(candidateName) == string.lower(text) then
      if found and found ~= candidate then found = -1 else found = candidate end
      name = candidateName
    end
  end
  if removing then
    for candidate, rule in pairs(SimpleAutoDelete.list) do consider(candidate, rule.name) end
  else
    for bag = 0, (NUM_BAG_SLOTS or 4) do
      for slot = 1, GetContainerNumSlots(bag) do
        local link = GetContainerItemLink(bag, slot)
        local candidate = itemID(link)
        if candidate then consider(candidate, linkName(link)) end
      end
    end
  end
  if found and found > 0 then return found, name end
  say("Название не найдено или неоднозначно. Используйте Shift-клик по предмету либо его точный item ID.")
  return nil
end

SLASH_SIMPLEAUTODELETE1 = "/simpleautodelete"
SLASH_SIMPLEAUTODELETE2 = "/sad"
SlashCmdList["SIMPLEAUTODELETE"] = function(text)
  if not ready then say("Настройки ещё не загружены."); return end
  local _, _, cmd, argument = string.find(trim(text), "^(%S+)%s*(.*)$")
  cmd, argument = string.lower(cmd or ""), argument or ""
  local db = SimpleAutoDelete
  if cmd == "add" or cmd == "remove" then
    local id, name = resolve(argument, cmd == "remove")
    if not id then return end
    if cmd == "add" then
      db.list[id] = {name = name}
      say("Добавлено: " .. name .. " [ID " .. id .. "]. /sad test — предварительная проверка.")
    else
      db.list[id] = nil
      if emptyList() then cancel() end
      say("Правило удалено: " .. name .. " [ID " .. id .. "].")
    end
  elseif cmd == "list" then
    if emptyList() then say("Список пуст."); return end
    local ids = {}
    for id in pairs(db.list) do table.insert(ids, id) end
    table.sort(ids)
    for _, id in ipairs(ids) do say((db.list[id].name or ("item:" .. id)) .. " [ID " .. id .. "]") end
  elseif cmd == "test" then
    deleteItems(true)
  elseif cmd == "run" then
    if emptyList() then say("Список пуст: удалять нечего."); return end
    manual = true
    pending, elapsed = true, db.delay
    frame:Show()
    say("Запрошена одна очистка. Если есть препятствия, она выполнится после их устранения.")
  elseif cmd == "on" or cmd == "off" or cmd == "toggle" then
    if cmd == "toggle" then db.enabled = not db.enabled else db.enabled = cmd == "on" end
    if db.enabled then schedule(false) else cancel() end
    say("Автоочистка " .. (db.enabled and "включена." or "выключена; отложенная очистка отменена."))
  elseif cmd == "status" then
    say("Автоочистка " .. (db.enabled and "включена" or "выключена") .. "; задержка " .. db.delay .. " с; " .. (pending and "есть отложенная проверка." or "проверка не ожидается."))
  elseif cmd == "delay" then
    local value = tonumber(argument)
    if value and value == value and value >= 0.1 and value <= 5 then db.delay = value; say("Задержка: " .. value .. " с.")
    else say("Допустимая задержка: от 0.1 до 5 секунд.") end
  elseif cmd == "print" then
    if argument == "true" then db.verbose = true elseif argument == "false" then db.verbose = false else db.verbose = not db.verbose end
    say("Сообщения об удалении " .. (db.verbose and "включены." or "выключены."))
  else
    say("/sad add <ссылка/ID/точное название>; /sad remove <ссылка/ID/название>; /sad list")
    say("/sad test — без удаления; /sad run — одна очистка; /sad on; /sad off; /sad toggle; /sad status")
    say("/sad delay <0.1–5>; /sad print <true/false>")
  end
end
